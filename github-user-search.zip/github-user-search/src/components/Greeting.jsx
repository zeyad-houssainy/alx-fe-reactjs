function Greeting() {
    return (
        <p>Use the search bar below to look for the API</p>
    )
}

export default Greeting;